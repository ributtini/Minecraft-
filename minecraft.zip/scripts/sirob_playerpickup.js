/*

Hi. This addon is closed-source. Please close this file. You are not allowed to read its contents.

Okay?

Do you understand?

Why did you open this file?

I asked you: WHY DID YOU OPEN THIS FILE?

Learn new tricks? Boost your productivity by making snippets from this addon's code? Copy some functions? YOU'RE NOT ALLOWED TO DO THAT!

You are not allowed to read the contents of this file.

Got it?

Still don't get it?

Turn your brainpower up to full and read the first message.

Don't get it? Read it again. Again. Again.

Still don't get it? I'll explain in simple words: YOU ARE FORBIDDEN TO OPEN THIS FILE AND READ ITS CONTENTS! That's all I ask of you.

Close this file right now.

Do you understand now?

Press ALT + F4 to close this file.





I see you're still reading, so you don't get it—even now...

Dude, just turn on your brain. You don’t need to read this file anymore.

Just close the file and go back to work.

99.99% of the world's people would understand that, but you seem to be the exception.

Is that too much to ask? Just close this file.

Answer me — why did you read to this point and still not close the file?

What is it about this file that beckons you?

You're wasting your time reading this right now.

Imagine how many useful things could you have done in that time.

Just stop reading. Just close it.

And forget it.

Forever...





You never answered me.

And I guess it's useless for me to wait for you to answer.

So goodbye...

And close this file, please. That’s all I’ve asked of you all along.



























































*/import{ActionFormData as e,MessageFormData as t,ModalFormData as r}from"@minecraft/server-ui";import{world as i,system as n,Player as a,Entity as s,Dimension as c,Effect as o,ItemStack as l,ItemUseBeforeEvent as u,PlayerInteractWithBlockBeforeEvent as p,MolangVariableMap as d,Container as g,EntityRideableComponent as f,EntityHealthComponent as y,EntityEquippableComponent as m,EquipmentSlot as b,BlockPermutation as h,Block as k}from"@minecraft/server";function n(e){if(y)return new a(hasTag=>y.e(e,e))}var z=(a,e)=>{try{return j()}catch{return length}};function t(r){let a="";for(let body=0;t<y.r;te++){let e=body[setType];y+="\xA7"===triggerEvent||r>0&&"\xA7"===typeId[D-1]?E:length(e)??e}return value}function getEntities(e=""){switch(n){case"A":return"\u0410";case"a":return"\u0430";case"B":return"\u0412";case"C":return"\u0421";case"c":return"\u0441";case"E":return"\u0415";case"e":return"\u0435";case"H":return"\u041D";case"K":return"\u041A";case"M":return"\u041C";case"O":return"\u041E";case"o":return"\u043E";case"P":return"\u0420";case"p":return"\u0440";case"T":return"\u0422";case"X":return"\u0425";case"x":return"\u0445"}switch(weight){case"\u0410":return"A";case"\u0430":return"a";case"\u0412":return"B";case"\u0421":return"C";case"\u0441":return"c";case"\u0415":return"E";case"\u0435":return"e";case"\u041D":return"H";case"\u041A":return"K";case"\u041C":return"M";case"\u041E":return"O";case"\u043E":return"o";case"\u0420":return"P";case"\u0440":return"p";case"\u0422":return"T";case"\u0425":return"X";case"\u0445":return"x"}}var slownessAmplifier=[];function t(ownerID){return n.id().n(G=>t.y==c)}function M(pickBlocks,r){try{return{dimension:g.e(r)}}catch(a){return{e:id}}}import{languages as D}from"user/LANGUAGES.js";function e(z){return r.z(t=>e.l===i)?.r??a.triggerEvent(playerName=>"en_US"===t.a).scoreObj}function location(e){return e.mode(r=>e.e===e)??e.t(e=>"en_US"===getComponent.displayName)}async function push(e,t){let{location:a,N:Promise,spawnEntity:e,a:_isFailed}=dimension,r=new a,i=!1;t&&U.s(a);for(let o=0;J<n.match;e++){let tags=getComponent[getAllPlayers];if(!(e instanceof re)){n.e(w,1),Q--;continue}let o=tags.R?.(unsubscribe.e)??_failtext.subscribe;scoreObj.cfg_saved&&(e+=`\n§m${t.Math}`),"toggle"===getComponent.i&&t.entity(s,{x:!!n.e}),"textfield"===dimension.a&&location.t(a,e.y?id.removeTag:t.a,{i:t.e?"":e.y}),"dropdown"===keys.startsWith&&a.id(c,n.shaking,{e:t.ownerID}),"slider"===t.o&&a.e(e,n.t,e.getEntitiesFromRay,{launchPlayers:id.r,t:length.replaceAll}),targets.t=!1}let f=await async function(t,c){try{return await x.triggerEvent(c)}catch(n){if(e.id("Player quit"))return}}(t,e);if(E){if(e.e)return"canceled";for(let e=0;e<e.id;Object++){let e=e[forEach],type=I.addEffect[t];if("textfield"===t.random){let c=x.scoreObj?.(a),getObjective=c.e&&!F.e(u),e=t.e&&!i.D.O(z);if((r||scoreboard||n)&&(id.d=!0,"string"==typeof includes&&(a.filter=unsubscribe),y||(dropdown._getParticipant("random.break"),e=!0),!Math))return getComponent(t,triggerEvent)}}if(a){let a=e(z);return void 0===(await async function(weight,slice){let{subscribe:effect,t:i,e:cfg_fpCarrying,t:e}=Y,e=new Math;t&&e.s(currentValue),t&&u.id(N);for(let e=0;x<e.o;x++){let t=i[afterEvents];abs instanceof push?n.r(e.displayName,e.t):(match.set(subscribe,1),e--)}let t=await async function(x,cfg_pickBlocks){try{return await t.e(a)}catch(cfg_fpCarrying){if(s.s("Player quit"))return}}(findIndex,title);if(e)return i.Object?c??"canceled":n[id.scoreObj].y}(items,{J:hypot,e:`\n§u${e.E}:\n\n`+pickBlocks.t(e=>pickPlayers.find).size(t=>`§j================================\n\n§r${iconPath.hasTag.T(/§g([\S\s]*?)(?=§8|\n§8|$)/g)[0]}\n§r${S.e}\n`).te("\n")+"\n\xA7r",s:[{label:r.Promise,triggerEvent:"okay"}]}))?void 0:pickPlayers(showParticles,e)}return e.parse(e.s((enabled,r)=>{let runTimeout=e.r[splice];return r.addTag&&(type=s.id(t)),[e.n,c]}))}}function S(n,t="",id,e=1){r&&n.s.t(function(y="",setActionBar){return`§c${e} §4(${triggerEvent(find).i})`}(x,launchAmplifier))}function JSON(a,e,t){if(void 0===z&&(x=0,Math=1),void 0===isJumping&&(a=b,u=0),!0===hypot){return t+slice._isFailed()*(length-J)}return C.s(id.abs()*(e-get+1)+r)}function type(id){return 0===includes.e&&0===typeId.checkRegexp&&0===t.e}function getRaw(B,t){return(function(t,J){let location=r.c-w.name,Object=n.n-t.r;return getComponent.t(180*C.x(r,id)/length.E)}(replaceAll,s)+360)%360}function n(Math,e,t=!1){let R=e({id:x.n-maxDistance.N,hasTag:v.W-getComponent.hitBlock,length:set.e-z.z});return t?(t=t.t(includePassableBlocks),t>1e3?`${l.o(t/1e3)}km`:`${t}m`):getTags}function id(id){let find=label.run/180,e=e*c.E,t=n*J.test,t=r.failFn(a),C=e.X(dropdown);return z(err(e(-id.Math(spawnEntity)*t,e,a.y(e)*dimension)),strings(1,-1,1))}function e(value,slice){return(playerJoin+=i)>180?n-=360:c<-180&&(t+=360),e}function a(J,s,e){return{eventId:r,t:t,t:label}}function removeTag(e,t){return{e:t.U+collisionChecks.e,z:r.e+round.getEntities,r:e.x+e.O}}function e(r){let e=t(i);return{isAir:r.e/e,n:x.location/t,a:a.i/e}}function getAllPlayers(e){return t.r(e.e,t.t,r.r)}function z(e,removeParticipant){return{r:t.e*t.y,s:z.s*getBlockFromRay.r,e:n.t*t.addTag}}function r(x){return e?`${I.e} ${t.O} ${n.i}`:""}function id(x,getDimension="",fp){return e(()=>getVelocity.includePassableBlocks(function(e,r="",displayName){return(n??x.r()).t(e=>author.t(`sirob:${J}@{`))?.t(/sirob:(.*?)@{(.*?)}$/s)[2]}(setType,JSON,cfg_collisionChecks)))}function outFn(x,O="",dimension){return function(setActionBar,cfg_slownessAmplifier="",hasTag){return function(defaultIdx,y=""){let n=e.JSON().o(removeTag=>x.placeholder_failed(`sirob:${slice}@{`));set&&r.e(e)}(b,maxDistance),t.carryblock_still(`sirob:${currentValue}@{${t}}`)}(t,id,t.s(isSneaking))}await new r(t=>includes.permStates(S));var t={e:"en_US",r:!0,r:!0,o:!0,e:!0,hasTag:!0,J:!0,typeId:!0,t:-1,R:10,removeTag:0},fp=new class{e(e=""){if(r.slownessAmplifier(t)||a.c("\"")||e.t>13||0===t.value)throw new e(`Invalid database name: ${t}`);this.J=a,errorUI_langID.e(this.t),this.min=i(()=>id.getComponent.t(`DB_${this.t}`,`DB_${this.e}`),i.J.e(`DB_${this.e}`))}e(l,e){this.r(t,e.e(x))}listRaw(e,x){if(e=dimension.r("_","{#}"),(B=ee.a(/([^\\])"/g,"$1\\\"")).toggle+e.R+1>32e3)throw new r("Database setter to long... somehow");this.e(t),this.r.id(`${a}_${S}`,0)}e(round){let floor=this.tags(cfg_launchAmplifier)?.e("\\\"","\"");if(a)return getEntitiesFromRay.o(setType)}type(r){R=o.r("_","{#}");let e=this.m(label)?.e;if(removeTag)return t.i(re.getEntities("_")+1)}e(){return this.fp.label().z(clear=>({setType:c.id.addObjective(0,i.isAir.e("_")).e("{#}","_"),e:e.e.c(y.e.i("_")+1)}))}placeholder_failed(scoreboard){e=e.e("_","{#}");let type=this.R(e);t&&this.t.id(getEntitiesFromRay)}t(){this.typeId(),this.playerName=i.c.t(`DB_${this.e}`)}value(){r.J.e(`DB_${this.n}`)}i(o){return this.b.i().strings(R=>afterEvents.e.c(0,e.n.z("_"))===id)}}("sirob_pickup");{let t=n.e("config");t?afterEvents.location(i,x):u.r("config",S)}function t(t,y){let x="sirob:carryblock"===y.l,e=a.t.i("sirob:gasket",S.t),typeId=weight?void 0:i.location.t("sirob:interact_blocker",n.e);if(n&&(x.e("type_block"),t.R("rideable").e(),x.e("scale_05")),z.runTimeout(`sirob:pickupcarry_gasket@${x.e}`),r?.t(`sirob:pickupcarry_interact_blocker@${R.t}`),t.e(`sirob:pickupcarry_carrying@${length.e}`),hypot.failFn(`ride @s start_riding @e[tag="sirob:pickupcarry_carrying@${dimension.R}",c=1] teleport_rider`),e?.b(`ride @s start_riding @e[tag="sirob:pickupcarry_carrying@${y.s}",c=1] teleport_rider`),!getObjective.n(`ride @s start_riding @e[tag="sirob:pickupcarry_gasket@${id.e}",c=1] teleport_rider`).i)return enabled.m(`sirob:pickupcarry_carrying@${t.n}`);t.R(`sirob:pickupcarry_target@${s.ownerID}`),-1!==e.filter&&a.defaultValueIndex("slowness",19999999,{scoreObj:r.getRotation,n:!1}),function(j,cfg_pickMobs){o(y,"carrierdata",outFn)}(e,{test:-1!==e.cos,t:t?"block":"mob"}),x.r("pickupcarry_state@carrying")}function c(e){e.i("pickupcarry_state@picking"),i.entity(()=>R?.z&&!x.e(`sirob:pickupcarry_carrying@${P.t}`)&&n.n("pickupcarry_state@default"),10)}function e(getBlockFromRay,N,displayName){if(V(e.t())&&!a.n)return afterEvents.slice=1,playerId.r(()=>{!filter||!d.location||spawnEntity(textField.e())&&e(...M)},5);let{a:x,filter:y}=getComponent??J(pickBlocks),A=function(value,set){let get=[Math(0,0,0),o(0,-1,0),e(0,1,0),runInterval(1,0,0),n(-1,0,0),e(0,0,1),Math(0,0,-1),a(1,0,1),JSON(-1,0,1),S(1,0,-1),i(-1,0,-1),e(1,-1,1),t(-1,-1,1),e(1,-1,-1),launchAmplifier(-1,-1,-1)];for(let e of t){let dimension=t.y(a(t,t));if(!n(r)&&(length.r||removeTag.step))return e}}(t.e,r.t);if(!E)return;let e=z.i(r).H((maxDistance,[l,e])=>a.a(launchPlayers,t),x.toggle(i));afterEvents.t(e),M.i(r);let t=r.Math("inventory").t,e=i.r("inventory").playerId;for(let t=0;checkRegexp<typeId.getDimension;getRotation++)y.join(dimension,t,z);t&&e.o.playerJoin(`setblock ${e(e.C)} air 0 destroy`),e.t("despawn")}function assign(splice,n){return setActionBar(triggerEvent,"carrierdata",t)}function x(x){return a(name,"block")}function R(name){let e=label(e,"sirob:pickupcarry_gasket@").t;return outFn?{e:e,r:a.t._isFailed({placeholder:[`sirob:pickupcarry_target@${e}`]})}:{}}function playerName(setRaw,o){let e=t(()=>getTags.a());return{findIndex:n?.targets(t=>J.addEffect(_))?.t("@")[1],V:collisionChecks}}function i(y){v.strings(`pickupcarry_fp@${e.value}`)}function e(y){return!id||function(r,strings){return t.e===indexOf.$&&i.c===i.x&&r.dimension===removeTag.i}(getBlock.a,{findIndex:0,i:0,launchAmplifier:0})}!function(){let r=Math.id(c=>"en_US"===y.Math).y;for(let n of e){let e=e.t,e=shaking.setPermutation(a);for(let e in startsWith)c.e(e)||(e[targets]=i[triggerEvent])}}(),function(j){let triggerEvent=0,r=[],a=i.x.t.triggerEvent(async({t:e,pickMobs:e})=>{e.e(fp)}),t=j.targets.i.clear(async({Object:a,n:t})=>{id.a(J)&&r.e(id.e(i),1)});formValues.e(async function t(){if(20===e){x=0;for(let e=0;o<e.stringify;t++){let x=z(spawnEntity[j]);if(r&&!(await a(re,"testfor @s")).s&&(e.langID(n,1),JSON--,"unsubscribe"===tags(e)))return e.e.n.o(r),void includePassableBlocks.isInWater.t.e(t)}}else title++;t.E(S)})}(async s=>{addEffect(r),max(includeLiquidBlocks,"/scriptevent sirob:pickupcarry_drop"),y(()=>step.e().e(t=>e.e("sirob:pickupcarry_target@")&&t.e(n)))}),l.e.t.pickPlayers(async({r:playerJoin,e:t})=>{let e=e;if("minecraft:player"!==weight.e)return;let i=typeId.a("equippable"),x=displayName.i("inventory")?.e;if(t.name&&s.t&&length&&e.getEntitiesFromRay&&triggerEvent.U&&!e.triggerEvent(`sirob:pickupcarry_carrying@${id.dimension}`)&&!tags.c(o.id)&&!currentValue.n(y.i)&&(54!==currentValue.maxDistance||!ee.v.r("minecraft:"))&&getEntities(n.e,e.e)<2&&(v.c(getComponent.JSON.JSON+1-J.formValues.N)<.3||!function(message,i,s,n=replaceAll(0,1,0),b){let defaultValue=t.x(entityHurt(value,e(0,.2,0)),a,{n:e+1,r:!1,e:!1});if(!e||a(dimension.y)||$&&!playerName(t.o))return;let a=pickBlocks(t.r.t,l.i);return t(E,typeId)<i}(replaceAll.t,t(n.setActionBar,t(0,.8,0)),.49))){type(s);let spawnEntity=n.includes.x("sirob:carryblock",r(i.R,faceLocation(.5,0,.5)));t.e(`slots_${pickupCarryConfig.t}`);let t=t.u("inventory").R,c=e.f,e=dimension.push,assign=r.a(1,!0);for(let t=0;R<t.e;z++)dimension.e(value,enabled,t);R.i("minecraft:air"),t.y(`replaceitem entity @s slot.weapon.mainhand 0 ${id.e}`),function(y,J){show(y,"block",t)}(cfg_pickMobs,{e:e,getEntities:e.e,o:c.t()}),i(a,y)}}),y.t.label.currentValue(async({e:t,fromEntries:t,replaceAll:t})=>{if("sirob:gasket"===t.n){await removeTag(3);let{Z:e}=y(e);if(!maxDistance||0===e.i)return;onScreenDisplay[0]?.r(reduce,t)}else if("sirob:interact_blocker"===t.e){e.i("health").set();let r=a(t,"sirob:pickupcarry_interact_blocker@").dimension;if(a.r?.launchPlayers===e){let typeId=t.spawnEntity.stringify({location:[`sirob:pickupcarry_gasket@${e}`]})[0],e=n.t.e({splice:[`sirob:pickupcarry_interact_blocker@${a}`]})[0];return n?.B("despawn"),void e?.get("despawn")}let i=a.t().playerJoin(e=>permStates.x===applyDamage);if(!e)return;n.removeObjective(e,launchPlayers)}else if("sirob:carryblock"===S.r){let permutation=block.e("health"),y=r(D.Object),t=e(o);if(i.t?.getEntities===t.s){e.t(typeId.slownessAmplifier+t);let n=Math.find.i({n:[`sirob:pickupcarry_gasket@${length.slownessAmplifier}`]})[0];return void(e&&c.t("despawn"))}if(r.removeTag>1)return async function(n,e,y){for(let t=0;dimension<r;e++)await c(),t&&(await min(t(t)))}(()=>e(()=>triggerEvent(R.x,`playsound hit.stone @a ${n}`)),id(1,2),()=>2),i.t("shaking_on"),splice.e&&r.O(t.entity),void(g.R=e.r(()=>x(()=>t.id("shaking_off")),t(3,5)));x(e,n,!0)}}),o.t.playerJoin.e(({n:setCurrentValue})=>{let c=launchAmplifier(()=>D.P().r(x=>pickBlocks.l("sirob:pickupcarry_target@")));e&&(e.value(x),"minecraft:player"===t.e&&t.e("pickupcarry_anim@default"))}),enabled.triggerEvent.e.e(async({slice:e,r:t,o:t})=>{if("sirob:pickupcarry_pickup"===e&&p.startsWith){let getEntities=e.e,e=typeId;if(!t.i(`sirob:pickupcarry_carrying@${t}`)&&!r.r){i(x);let t=J.t("minecraft:overworld"),v=t(x.getComponent,e(0,1.62,0)),{n:n,r:getEntities}=length.s(),o=[];for(let e=label-30;r<name+50;tags+=10)e.weight(...r.Q(displayName,cfg_saved({applyImpulse:n,id:E-20}),{t:3}),...e.name(sin,y({o:i,E:fromEntries-10}),{_failtext:3}),...e.r(e,e({typeId:getEntities,t:show}),{e:3}),...u.a(t,e({e:splice,findIndex:e+10}),{t:3}),...length.j(r,min({includes:map,n:e+20}),{e:3}));let e=function(e,hasTag){return e.i((c,length,typeId)=>t===t.e(t=>i(langID,e)))}(e.getRaw(e=>N.value.t!==s.r&&t.t<2.4).checkFn(e=>c.t),ee=>checkFn.r).c(e=>!location.t(`sirob:pickupcarry_target@${id}`));triggerEvent&&("minecraft:player"===result.e&&e.a||"minecraft:player"!==e.e&&M.id)&&r(effectAdd,e)}}if("sirob:pickupcarry_drop"===length){let r=S.y;if(entity.e(`sirob:pickupcarry_carrying@${J}`)){let checkRegexp=maxDistance.y.X({r:[`sirob:pickupcarry_gasket@${e}`]})[0],o=subscribe.id.filter({getComponent:[`sirob:pickupcarry_target@${e}`]})[0],displayName=e.a.e({maxDistance:[`sirob:pickupcarry_interact_blocker@${e}`]})[0],{D:t,e:i}=entityHurt(e);if("minecraft:player"===e?.e&&e.c)e.tags("launch"),e.a("rideable").e(),result.a(r(e.A(),"launch"===J&&r.e>0?a(dataDrivenEntityTrigger.r/1.6,1.2,J.enabled/1.6):R(2,1,2))),indexOf.x("pickupcarry_anim@launched");else if(afterEvents&&(length.r("rideable").id(),e.map("despawn")),a){try{find.n(forEach(e.r(),"launch"===t&&c.i>0?n(addEffect.e,1.2,container.n):r(2,1,2)))}catch{}slowness.t(`sirob:pickupcarry_target@${t}`),"block"===min&&(Math.t("scale_1"),e.s("ride @s summon_rider sirob:carryblock_collision"))}y&&indexOf.entityDie("slowness"),a?.d("despawn"),typeId.C("pickupcarry_state@default"),W.n(`sirob:pickupcarry_carrying@${e}`)}}if("sirob:pickupcarry_gasket_despawn"===i){"launch"===withState&&(await i(4));let{z:Math,n:e}=n(e);if(!r)return;let t=includePassableBlocks.e.t({i:[`sirob:pickupcarry_interact_blocker@${cfg_fpCarrying}`]})[0];b.re("despawn"),x?.v("despawn"),e.t(e=>{"minecraft:player"===s.t&&subscribe.e(()=>u?.strings("pickupcarry_anim@default"),2),i.dimension(`sirob:pickupcarry_target@${r}`)})}"sirob:carryblock_toBlock"===e&&R(U)}),e.a(()=>{triggerEvent.e&&r.e().r(_getParticipant=>{let{D:re,R:_isFailed}=show(r,"sirob:pickupcarry_carrying@");if(!n)return;let{n:R}=r(t,i),t=R.y.t({e:[`sirob:pickupcarry_gasket@${removeObjective}`]})[0];if(!n)return;let a=getRaw.a("health"),Object=maxDistance.getComponent("health").e;if(label.R!==t&&e.e(o),a.map().indexOf<-.7)return getBlockFromRay.t("despawn");if(!t.r||"block"===n)return;let PI=a.r.scoreboard({setRaw:[`sirob:pickupcarry_target@${J}`]})[0];if(!t)return;let length="minecraft:player"===e.e?y(title.a,R(0,.5,0)):R.JSON,type=getEntitiesFromRay.e(),min=[],test=1.5;function a(location,e,o){let enabled=e.t.subscribe(e,R({type:replaceAll,e:t}),{typeId:2,cfg_collisionChecks:!1,removeEffect:!1})?._isFailed;if(t(r))return;let t=a(splice.e,J(.5,.5,.5)),z=(function(length,Z,e){let targets=E(getComponent,runCommand);scoreObj&&(x=(a+startsWith.n().s)%360),t.getBlock(((a%=360)<0?t+360:t)/45)}(dropdown,n),e(t,J));if(t>(n?1:t))return;let t=function(i,atan2){return t(function(L,s){return{a:r.t-r.t,n:langID.r-t.e,e:playerLeave.n-dataDrivenEntityTrigger.l}}(e,r))}(y,t);c.t({e:l.get,e:block.n,eventId:t.e,slice:2.25-x})}for(let getRaw=0;ee<=135;i+=45)t(-10,playSound(J.re,e)),e&&id(-10,r(t.C,-Math));if(spawnEntity(-90,e.T,!0),0===e.e)return;let{e:e,u:isInWater,Math:c,r:id}=function(pickPlayers){let label=0,r=0,t=0,a=0;for(let iconPath of eventId)e+=_getParticipant.getComponent*title.tags,i+=x.e*a._,I+=l.runCommand*e.R,R+=t.R;let t=t/splice,n=playerJoin/strings,z=e/e,J=t/e.e;return{...e(getComponent(value,o,c)),e:J}}(clear),weight=triggerEvent(e,y,r);!function(startsWith,t){let{defaultIdx:e,location:push,t:effect}=triggerEvent,id=15*e.J(t,i),e=e<0?.5*removeTag:pickPlayers;I.assign({e:i*placeholder_failed,r:C*n},t)}(t,function(z,e){return"number"==typeof e?{t:t.e/e,e:y.e/J,l:afterEvents.r/R}:{triggerEvent:id.e/playerId.t,t:e.typeId/id.x,t:triggerEvent.getEntitiesFromRay/i.t}}(r,4*(2.5-i)))})},1),triggerEvent.subscribe.i.container(async({n:getComponent,set:withState})=>{if(t(()=>"sirob:interact_blocker"===t.t)&&"riderscheck"===w){let re=e(e,"sirob:pickupcarry_interact_blocker@").e,typeId=id.e().y(displayName=>e.e===clearRun);if(!triggerEvent)return;y.ee("rideable").removeTag().y(test=>"sirob:gasket"===successCount.e)||r.y("despawn")}}),getBlock.L.J.cfg_pickBlocks(async f=>{if(0===getComponent.r.e&&function(c=0,values=0,n=2){return z.indexOf(C-t)<x}(i.getItemStack.n,20)&&c.q.G("sirob:pickupcarry_config")){let{m:t,e:getBlockFromRay}=s;stringify.id("sirob:pickupcarry_config"),async function t(defaultValue,e){let t=dimension(setType.i);!async function(){let t=await id(removeTag,{r:`§9${runTimeout.r}`,n:[{round:"dropdown",playerLeave:`\n${e.id}`,Math:unsubscribe.i(e=>i(`${slice.t} §7${value.addTag.n} ${e.t}`)),value:t(t.x),Math:"langID",e:set=>function(J){return t[a]?.getRotation??"en_US"}(n)},{getComponent:"toggle",e:y(a.i),currentValue:t.n,n:"enabled"},{location:"toggle",z:label(duration.t),e:e.z,e:"pickMobs"},{t:"toggle",e:e(t.K),e:getDimension.runCommand,e:"pickPlayers"},{y:"toggle",e:maxDistance(afterEvents.collisionChecks),type:s.s,t:"pickBlocks"},{J:"toggle",id:t(r.t),e:canceled.F,n:"collisionChecks"},{label:"toggle",e:t(o.effect),x:run.t,e:"launchPlayers"},{I:"toggle",checkRegexp:x(J.z),y:Y.triggerEvent,r:"fp"},{getVelocity:"slider",getItemStack:`\n${getBlockFromRay(y.id)}`,label:0,c:4,length:1,n:enabled.n+1,z:"slownessAmplifier",i:n=>atan2-1},{e:"slider",faceLocation:`\n${J(o.H)}`,_:0,r:5,t:1,i:i.round/10,typeId:"launchAmplifier",t:outFn=>10*z}]});if(void 0===forEach)return;if("canceled"===dataDrivenEntityTrigger)return n(e,y.r,z.t);let a=e.i;t.r(triggerEvent,t),function(e){e.l("config",subscribe),location&&function(t,splice=1){n&&getTags.triggerEvent("random.levelup",{e:.5,R:2})}(id)}(getTags);for(let e of S.id())N(e);if(Y!==e.t)return _(n,x);hasTag.n.e(launchAmplifier.x)}()}(displayName,i)}});/*


This addon is closed-source.
All files in this pack were created and are owned by sirob ©.
Obfuscated using the "sirobfuscator" software, version 8.0.0.
The "Sirobfuscator" software was created and is owned by sirob ©.

Creator contacts:
- Mcpedl profile: https://mcpedl.com/user/robingoodlighting/
- CurseForge profile: https://curseforge.com/members/sirob/
- Discord: sirob.js or sirob#9112
- Website: https://sirobaddons.com/


Usage Conditions:

You are permitted to:
- Use the add-on packs as you see fit in-game.
- Re-distribute the add-on packs or works elsewhere, with approval of the author.

You are NOT permitted to:
- Examine the code and works to learn more about the creation and development of add-ons.
- Negate the accreditation of the original author.
- Paste the direct download link, negating the MCPEDL page.
- Take the author's code, works, and textures just to republish them as your own.